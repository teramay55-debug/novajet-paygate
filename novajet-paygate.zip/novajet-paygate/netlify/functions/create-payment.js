const USDC_WALLET = "0xeABA510c0F7286B894A7C9229F41dC1ee0e8038E";

exports.handler = async (event) => {
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Content-Type': 'application/json'
    };
    
    if (event.httpMethod === 'OPTIONS') {
        return { statusCode: 204, headers, body: '' };
    }
    
    try {
        const { amount, order_id, customer_name, customer_email, customer_phone } = JSON.parse(event.body);
        
        console.log('Creating PayGate.to payment:', { order_id, amount, customer_name, customer_email });
        
        // Method 1: Direct to PayGate.to hosted payment page (where they enter card details)
        const paymentUrl = `https://paygate.to/pay?` + new URLSearchParams({
            amount: amount.toFixed(2),
            currency: 'USD',
            address: USDC_WALLET,
            order_id: order_id,
            name: customer_name,
            email: customer_email,
            phone: customer_phone || '',
            description: `NovaJet Flight: ${customer_name}`,
            callback_url: `${event.headers.origin}/.netlify/functions/payment-callback`,
            success_url: `${event.headers.origin}/?payment=success&order_id=${order_id}`,
            cancel_url: `${event.headers.origin}/?payment=cancelled&order_id=${order_id}`
        }).toString();
        
        console.log('Payment URL:', paymentUrl);
        
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                success: true,
                payment_url: paymentUrl,
                order_id: order_id
            })
        };
        
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: error.message })
        };
    }
};